#ifndef play_h
#define play_h
#include "game_class.h"



void gameModify(game::Game& g);
void menu();
game::Game gameCreator(int x);
#endif
