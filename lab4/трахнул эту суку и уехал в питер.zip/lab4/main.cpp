
/*
#include "game_class.h"
#include "module.h"
#include "component.h"
#include "criminal.h"
#include "module.h"
#include "platform.h"
#include <iostream>
#include "classes/List.h"
#include "classes/List.cpp"
#include <memory>
 */
#include <iostream>
#include "play.h"
//using namespace game;

using namespace std;
/*

char func(int x){
    return 'a';
}


int main(){
    List<int> l;
    for (int i = 0; i < 5; ++i) l.push_back(i);
    List<char> l2 = select(l, func);
    l2.print();
}
 
 */


int main(){
                        
    menu();
        
        
}





// g++ -std=c++17 ../module.cpp ../game_class.cpp ../platform.cpp ../field.cpp ../criminal.cpp ../component.cpp main.cpp

